package utfpr;

import utfpr.http.ClienteHttp;
import java.lang.reflect.Type;
import java.util.List;


public class Main {

    public static void main(String[] args) {
        ClienteHttp cliente = new ClienteHttp();
        String baseUrl = "https://servicodados.ibge.gov.br/api/v1/localidades/estados";
        String result = cliente.buscaDados(baseUrl);
        
         // Converter a string result em uma lista de objetos Municipio
      /*  List<UF> ufs = converter(result);     
           
       
      
                // Agora você pode acessar os objetos Municipio na lista
                 for (UF uf : ufs) {
                System.out.println("nome: " + uf.getNome());
                System.out.println("id: " + uf.getId());
                System.out.println("sigla: " + uf.getSigla());
                System.out.println("região: " + uf.getRegiao().getNome());
                System.out.println();
                */
                }
      }

        
    
    

